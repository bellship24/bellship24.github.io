# [Git] gitflow 란?

Column: Jun 19, 2020 1:33 PM
Tags: git

- Gitflow는 5가지 종류의 브랜치로 구성
- 항상 유지되는 메인 브랜치들(master, develop)과 일정 기간 동안만 유지되는 보조 브랜치들(feature, release, hotfix)로 구성
- Gitflow의 브랜치 종류
    1. master : 제품으로 출시될 수 있는 브랜치
    2. develop : 다음 출시 버전을 개발하는 브랜치
    3. feature : 기능을 개발하는 브랜치
    4. release : 이번 출시 버전을 준비하는 브랜치
    5. hotfix : 출시 버전에서 발생한 버그를 수정 하는 브랜치

    ![%5BGit%5D%20gitflow%20%E1%84%85%E1%85%A1%E1%86%AB%2007caaf1df98347c7b437a7f25821f02a/Untitled.png](%5BGit%5D%20gitflow%20%E1%84%85%E1%85%A1%E1%86%AB%2007caaf1df98347c7b437a7f25821f02a/Untitled.png)

- release 브랜치
    - develop브랜치에 이번 버전에 포함하는 모든 기능이 merge되었다면 , QA를 위해 develop브랜치에서 release브랜치를 생성
    - QA를 무사히 통과하게되면 relase브랜치를 master와 develop브랜치로 merge 합니다.
    - QA를 진행하면서 발생한 버그들은 모두 release브랜치에 수정되게 됩니다